import time  #운영 체제의 시간 관련 모듈 
import serial #블루투스 시리얼 통신을 위한 모듈
from timeit import default_timer as timer #
import threading # 쓰레드 생성하기 위한 모듈  

te=0
tx_d = [2,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3]
rx_data= [0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0]
rx_d = [2,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3]
rx_d56 = [0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0]
rx_ddata = [0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0]
rx_dsensor1 = [0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0]

ser = serial.Serial() #B
ser.baudrate = 115200 #Bluetooth serial baudrate
ser.timeout = 2000
port='com3'

rxcnt=0
speed = 0
connectstate = 0

class SensorData :
    hum = 0
    heater = 0
    temp = 0
    moisture = 0
    cds = 0
    sw=[0,0,0,0]


sensor=SensorData
    
def startTimer():
    global connectstate
    global rxcnt
    
    if connectstate == 1 :
        try :
            timer = threading.Timer(0.05, startTimer)
            timer.start()
            sensor = SensorFun(10)            
        except KeyboardInterrupt:            
            Close()

def Open(portName=port) :
    global connectstate
    global ser   
    ser.port=portName #Bluetooth serial port
    ser.open()
    connectstate = 1
    delay(500)
    startTimer()
    print("IOTSmartfarm connect")

def BT(portName=port) :
    Open(portName)

def Bt(portName=port) :
    Open(portName)

def bt(portName=port) :
    Open(portName)
    
def Close() :
    global connectstate
    delay(1000)
    connectstate = 0    
    ser.close()
    print("IOTSmartfarm disconnect")

def close() :
    Close()

def delay(ms):
    time.sleep(ms/1000)

def Delay(ms):
    delay(ms)

def check():
    tx_d[0]=2
    tx_d[1]=22
    te=0    
    for i in range(3,21):
        te=te+tx_d[i]

    te=te%256
    tx_d[2]=te
    tx_d[21]=3
    ser.write(bytearray(tx_d))

def Window(OnOff=0):    
    if OnOff== 0 :
        tx_d[5]=tx_d[5] & 0xFE
    else :
        tx_d[5]=tx_d[5] | 0x01

def window(OnOff=0):
    Window(OnOff)


def Fan(OnOff=0):    
    if OnOff== 0 :
        tx_d[5]=tx_d[5] & 0xFD
    else :
        tx_d[5]=tx_d[5] | 0x02        

def fan(OnOff=0):
    Fan(OnOff)

def Pump(OnOff=0):    
    if OnOff== 0 :
        tx_d[5]=tx_d[5] & 0xFB
    else :
        tx_d[5]=tx_d[5] | 0x04

def pump(OnOff=0):
    Pump(OnOff)

def Heater(OnOff=0):    
    if OnOff== 0 :
        tx_d[5]=tx_d[5] & 0xF7
    else :
        tx_d[5]=tx_d[5] | 0x08
        
def heater(OnOff=0):
    Heater(OnOff)
    
def Camera(angle=0):    
    tx_d[5] = (tx_d[5] & 0x0F) | (angle*16 & 0xF0)

def Cam(angle=0):
    Camera(angle)
    
def cam(angle=0):
    Camera(angle)
    
def Led(num=1, r=0, g=0, b=0) :
    if num ==1 :
        tx_d[6]= g*16 +r
        tx_d[7]= (tx_d[7]&0xF0) + b
    elif num == 2:
        tx_d[7]= (tx_d[7]&0x0F) +r*16
        tx_d[8]= b*16 + g
    elif num ==3 :
        tx_d[9]= g*16 +r
        tx_d[10]= (tx_d[10]&0xF0) + b
    elif num == 4:
        tx_d[10]= (tx_d[10]&0x0F) +r*16
        tx_d[11]= b*16 + g
    elif num == 5:
        tx_d[6]= g*16 +r
        tx_d[7]= r*16 + b        
        tx_d[8]= b*16 + g
        tx_d[9]= g*16 +r         
        tx_d[10]= r*16+ b
        tx_d[11]= b*16 + g

def led(num=1, r=0, g=0, b=0) :
    led(num, r, g, b) 

def Display(str="Smartfarm"):
    result=bytes(str,'utf-8')
    cnt=len(str)
    if cnt == 1:
        tx_d[12]=result[0]
    elif cnt == 2:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
    elif cnt == 3:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]
    elif cnt == 4:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]        
        tx_d[15]=result[3]
    elif cnt == 5:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]        
        tx_d[15]=result[3]
        tx_d[16]=result[4]
    elif cnt == 6:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]        
        tx_d[15]=result[3]
        tx_d[16]=result[4]
        tx_d[17]=result[5]
    elif cnt == 7:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]        
        tx_d[15]=result[3]
        tx_d[16]=result[4]
        tx_d[17]=result[5]
        tx_d[18]=result[6]
    elif cnt == 8:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]        
        tx_d[15]=result[3]
        tx_d[16]=result[4]
        tx_d[17]=result[5]
        tx_d[18]=result[6]
        tx_d[19]=result[7]
    elif cnt >= 9:
        tx_d[12]=result[0]
        tx_d[13]=result[1]
        tx_d[14]=result[2]        
        tx_d[15]=result[3]
        tx_d[16]=result[4]
        tx_d[17]=result[5]
        tx_d[18]=result[6]
        tx_d[19]=result[7]
        tx_d[20]=result[8]
    
def display(str="Smartfarm"):
    Display(str)

def SensorFun(command) :
    try:        
        check()
        
        rx_data=ser.read(22)
        for cnt in range(0,22) :
            for cnt1 in range(0,21) :
                rx_d[cnt1]=rx_d[cnt1+1]

            rx_d[21]=rx_data[cnt]
        
            rx_check_sum=0        
            if rx_d[0]==2 and rx_d[21] == 3 and rx_d[1] == 16 :
                
                
                for cnt3 in range(3,21) :                
                    rx_dsensor1[cnt3]=rx_d[cnt3]

                for cnt2 in range(0,22) :
                    rx_d[cnt2]=0
   
        sensordata1 = SensorData

        sensordata1.hum = (rx_dsensor1[5] + rx_dsensor1[6] * 256)/100

        sensordata1.heater = (rx_dsensor1[7] + rx_dsensor1[8] * 256)/100

        sensordata1.temp = (rx_dsensor1[9] + rx_dsensor1[10] * 256)/100

        sensordata1.moisture = rx_dsensor1[11] + rx_dsensor1[12] * 256

        sensordata1.cds = rx_dsensor1[13] + rx_dsensor1[14] * 256

        if (rx_dsensor1[16] & 0x01) ==0x01 : sensordata1.sw[1]=1
        else : sensordata1.sw[1]=0
        if (rx_dsensor1[16] & 0x02) ==0x02 : sensordata1.sw[2]=1
        else : sensordata1.sw[2]=0
        if (rx_dsensor1[16] & 0x04) ==0x04 : sensordata1.sw[3]=1
        else : sensordata1.sw[3]=0
        
        return sensordata1
    
    except :
        pass




    
    
