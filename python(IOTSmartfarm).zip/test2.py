from IOTSmartfarm import*
bt()
Led(5,15,0,0)
delay(3000)


close()
