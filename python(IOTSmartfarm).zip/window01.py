from IOTSmartfarm import*
bt1=33
bt()

while 1:
    if sensor.cds < 500 :
        Led(5,15,15,15)
    else:
        Led(5,0,0,0)

    if sensor.heater <27 :
        heater(1)
        window(0)
    if sensor.heater > 33 :
        heater(0)
        window(1)

    if sensor.moisture < 900 :
        pump(1)
    else :
        pump(0)
    if sensor.hum > 60 :
        fan(1)
    else :
        fan(0)
    

close()
