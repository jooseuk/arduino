from IOTSmartfarm import*

bt()
cam(15);delay(1000)
cam(0);

close()
