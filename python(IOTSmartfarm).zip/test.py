from IOTSmartfarm import*

bt()

while 1:
    print(sensor.cds)
    delay(200)

close()
