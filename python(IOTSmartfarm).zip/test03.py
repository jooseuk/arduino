from IOTSmartfarm import*

Open()

close()
