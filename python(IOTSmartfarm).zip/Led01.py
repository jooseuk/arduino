from IOTSmartfarm import*

bt()
Led(5,15,0,0);delay(500)
Led(5,0,15,0);delay(500)
Led(5,0,0,15);delay(500)

close()
