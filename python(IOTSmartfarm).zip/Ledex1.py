from IOTSmartfarm import*
bt()
for x in range(0,16):
    Led(5,x,x,x)
    delay(200)
for x in range(15,-1,-1):
    Led(5,x,x,x)
    delay(200)
close()
