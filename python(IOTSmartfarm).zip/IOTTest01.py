from IOTSmartfarm import*

bt()

window(1);fan(1);pump(1);heater(1) #1 On, 0 Off
delay(2000)
window(0);fan(0);pump(0);heater(0)
delay(2000)
cam(15)  #0(0도) ~ 15(180도)
delay(2000)
cam(0)
delay(1000)
Led(1,15,0,0) #첫번째 인자 1,2,3,4 LED 표시
delay(1000)
Led(2,0,15,0) #두번째 인자 Red:0~15
delay(1000)
Led(3,0,0,15) #세번째 인자 Green:0~15
delay(1000)
Led(4,15,15,15)#네번째 인자 Blue:0~15
delay(1000)
display("kang")

close()
