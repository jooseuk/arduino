from IOTSmartfarm import*

bt()

while 1:
    if sensor.sw[1] == 1:
        Led(5,15,15,15)
    else:
        Led(5,0,0,0)

close()
